/**
 * Write a description of class mainClient here.
 *
 * @author (M_R)
 * @version (a version number or a date)
 */
public class MainClient {
    // instance variables - replace the example below with your own
    public static void main(String[] args) {
        Client client = new Client("127.0.0.1", "5000");
    }
}
