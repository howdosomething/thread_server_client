/**
 * Write a description of class main here.
 *
 * @author (M_R)
 * @version (a version number or a date)
 */
public class MainServer {
    // instance variables - replace the example below with your own
    public static void main(String[] args) {
        Server base = new Server("5000");
    }
}
